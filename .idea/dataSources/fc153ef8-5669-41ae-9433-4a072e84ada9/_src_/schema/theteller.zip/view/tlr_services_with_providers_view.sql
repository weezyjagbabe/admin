CREATE VIEW tlr_services_with_providers_view AS
  SELECT
    `theteller`.`tlr_services_providers`.`providerID`     AS `providerID`,
    `theteller`.`tlr_services_providers`.`companyName`    AS `companyName`,
    `theteller`.`tlr_services_providers`.`companyEmail`   AS `companyEmail`,
    `theteller`.`tlr_services_providers`.`companyPhone`   AS `companyPhone`,
    `theteller`.`tlr_services_providers`.`companyLogo`    AS `companyLogo`,
    `theteller`.`tlr_services_providers`.`companyAddress` AS `companyAddress`,
    `theteller`.`tlr_services_providers`.`aboutProvider`  AS `aboutProvider`,
    `theteller`.`tlr_services_providers`.`serviceIDS`     AS `serviceIDS`,
    `theteller`.`tlr_services_providers`.`companyStatus`  AS `companyStatus`,
    `theteller`.`tlr_services_providers`.`providerKey`    AS `providerKey`,
    `theteller`.`tlr_services_providers`.`dateJoined`     AS `dateJoined`,
    `theteller`.`tlr_services`.`serviceID`                AS `serviceID`,
    `theteller`.`tlr_services`.`serviceName`              AS `serviceName`,
    `theteller`.`tlr_services`.`serviceDesc`              AS `serviceDesc`,
    `theteller`.`tlr_services`.`commissionCharge`         AS `commissionCharge`,
    `theteller`.`tlr_services`.`serviceStatus`            AS `serviceStatus`,
    `theteller`.`tlr_services`.`serviceKey`               AS `serviceKey`,
    `theteller`.`tlr_services`.`serviceLogo`              AS `serviceLogo`,
    `theteller`.`tlr_categories`.`categoryID`             AS `categoryID`,
    `theteller`.`tlr_categories`.`categoryName`           AS `categoryName`,
    `theteller`.`tlr_categories`.`categoryKey`            AS `categoryKey`
  FROM ((`theteller`.`tlr_services_providers`
    JOIN `theteller`.`tlr_services`
      ON ((`theteller`.`tlr_services_providers`.`providerKey` = `theteller`.`tlr_services`.`providerKey`))) JOIN
    `theteller`.`tlr_categories`
      ON ((`theteller`.`tlr_services`.`categoryID` = `theteller`.`tlr_categories`.`categoryID`)));
