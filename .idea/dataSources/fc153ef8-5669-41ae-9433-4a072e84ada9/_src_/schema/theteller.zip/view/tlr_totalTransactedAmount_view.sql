CREATE VIEW tlr_totalTransactedAmount_view AS
  SELECT sum(`theteller`.`tlr_transactions`.`transactionAmount`) AS `transactedAmount`
  FROM `theteller`.`tlr_transactions`
  WHERE (`theteller`.`tlr_transactions`.`transactionStatus` = 1);
